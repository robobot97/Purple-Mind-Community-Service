function changeColor() {
  document.body.style.backgroundColor = "purple";
}

window.onload = changeColor;

function parallax() {
  var hero = document.querySelector(".hero");
  var scrollY = window.scrollY;
  hero.style.top = -scrollY / 2 + "px";
}

window.addEventListener("scroll", parallax);
